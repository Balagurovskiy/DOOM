/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obalagur <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/22 11:52:40 by obalagur          #+#    #+#             */
/*   Updated: 2018/06/22 11:52:46 by obalagur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF_H
# define WOLF_H



# include <math.h>
# include <pthread.h>

# include "libft.h"
# include "get_next_line.h"


# include <stdio.h>

/**********//* map */


typedef	struct		s_map_vertex
{
	// char					*neighbor;
	int						neighbor;
	int						x;
	int						y;

	struct	s_map_vertex 	*next;
}					t_map_vertex;

typedef	struct		s_map_sector
{
	t_map_vertex	*vertex;
	int				vertex_size;

	int				floor;
	int				ceil;

	char			*next_level;
	int				next_level_sector;

	struct	s_map_sector 	*next;
}					t_map_sector;


typedef	struct		s_map
{
	t_map_sector	*sector;
	int				sector_size;
}					t_map;

t_map_vertex		*map_new_vertex();
void			map_add_vertex(t_map_vertex **first, t_map_vertex *new);
void			map_del_vertex(t_map_vertex **node);

t_map_sector		*map_new_sector();
void			map_add_sector(t_map_sector **first, t_map_sector *new);
void			map_del_sector(t_map_sector **node);

#endif
