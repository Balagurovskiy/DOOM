/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_selector.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obalagur <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/22 14:18:13 by obalagur          #+#    #+#             */
/*   Updated: 2018/06/22 14:18:15 by obalagur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parser.h"

char	*map_select(char *argv)
{
	if (ft_strequ(argv, "1"))
		return ("src/map/level1");
	if (ft_strequ(argv, "2"))
		return ("src/map/level2");
	if (ft_strequ(argv, "3"))
		return ("src/map/level3");
	if (ft_strequ(argv, "4"))
		return ("src/map/level4");
	if (ft_strequ(argv, "5"))
		return ("src/map/level5");
	return (0);
}