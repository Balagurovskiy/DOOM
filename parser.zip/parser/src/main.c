/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: obalagur <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/22 12:01:50 by obalagur          #+#    #+#             */
/*   Updated: 2018/06/22 12:02:58 by obalagur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include "parser.h"

char	*str_cut(char *line, int start, int end)
{
	char	*cut;
	int		length;
	int 	i;

	i = -1;
	cut = NULL;
	length = end - start;
	if (length <= 0 || line == NULL)
		return (cut);
	cut = (char *)malloc(sizeof(char) * length);
	while (++i < length)
		cut[i] = line[start + i];
	cut[i - 1] = '\0';
	return (cut);
}

char	*cut_str_value(char *line, char *start, char *end)
{
	int	start_idx;
	int	end_idx;

	start_idx= ft_str_contains(line, start);
	end_idx= ft_str_contains(line, end);
	if (!start_idx || !end_idx)
		return (NULL);
	return(str_cut(line, start_idx, end_idx));
}

void   loop_str_to_value(char **line, char *value, int condition)
{
	if (condition)
		*line = *line + ft_str_contains(*line, value);
}

int	char_isdigit(int c)
{
	return (c >= '0' && c <= '9');
}

int	str_isdigit(char *s)
{
	int i;
	int isdigit;

	i = -1;
	isdigit = 1;
	if (s)
		while (s[++i])
			if (!char_isdigit(s[i]) && (s[i] != '-'))
				isdigit = 0;
	return (isdigit);
}

int    iterate(int max)
{
	static int i = 0;
	
	i++;
	if (i == max)
		i = 0;
	return (i);
}

t_map   *line_parser(char *line)
{
	static t_map *map;

	static int 	sector_size = 0;
	static t_map_sector *map_sector = NULL;

	static char *flags[] = {"ceil:\0", "floor:\0", "sectors:\0", "level:\0"};
	// char 		**cuts;

	
	if (line)
	{
		// splited_line = ft_splinter(line, ";");
		////////////////////////////
		// int i = -1;
		// int flags_size = 4;
		// cuts = (char **)malloc(sizeof(char *) * flags_size + 1);
		// while (++i < flags_size)
		// {
		// 	cuts[i] = cut_str_value(line, flags[i], ";\0");
		// 	loop_str_to_value(&line, ";\0", cuts[i] != NULL);
		// }
		// cuts[i] = "\0";

		// i = -1;
		// while (++i < flags_size)
		// {
		// 	printf("%s\n", cuts[i]);
		// }

		// i = -1;
		// while (++i < flags_size)
		// {
		// 	ft_memdel((void **)&(cuts[i]));
		// }
		// ft_memdel((void **)&(cuts));
		// while(splited_line[sector_size]){
				// }
		// ft_memdel((void **)&splited_line);
		////////////////////////
		t_map_sector *map_sector_new = NULL;
		map_sector_new = map_new_sector();
//--------------------------------------------------//
			char *ceil = cut_str_value(line, "ceil:\0", ";\0");

			if (ceil && str_isdigit(ceil))
			{
				map_sector_new->ceil = ft_atoi((const char *)ceil);
				// printf("ceil:%d\n", ceil_int);
			}

			loop_str_to_value(&line, ";\0", ceil != NULL);
			ft_memdel((void **)&ceil);

//--------------------------------------------------//
			char *floor = cut_str_value(line, "floor:\0", ";\0");

			if (floor && str_isdigit(floor))
			{
				map_sector_new->floor = ft_atoi((const char *)floor);
				// printf("ceil:%d\n", ceil_int);
			}

			loop_str_to_value(&line, ";\0", floor != NULL);
			ft_memdel((void **)&floor);

//--------------------------------------------------//
			char *sectors = cut_str_value(line, "sectors:\0", ";\0");
			if (sectors)
			{
				char **vertex = ft_splinter(sectors, ",{}");
				int i = 0;
				int	vertex_size = 0;
				int it = 0;
				t_map_vertex *v = NULL;
				t_map_vertex *v_next = NULL;
				while (vertex[i])
				{
					
					if (it == 0){
						vertex_size++;
						//x
						v_next = map_new_vertex();
						if (vertex[i] && str_isdigit(vertex[i]))
							v_next->x = ft_atoi((const char *)vertex[i]);
						else
							printf("[]EXCEPTION sector not digit\n\n");
						 
						// printf("X : %s|%p   %d\n", vertex[i], vertex[i], it);
					}
					if (it == 1){
						//y
						if (vertex[i] && str_isdigit(vertex[i]))
							v_next->y = ft_atoi((const char *)vertex[i]);
						else
							printf("[]EXCEPTION sector not digit\n\n");
						// printf("Y : %s|%p   %d\n", vertex[i], vertex[i], it);
					}
					if (it == 2){
						//neib
						if (vertex[i] && str_isdigit(vertex[i]))
							v_next->neighbor = ft_atoi((const char *)vertex[i]);
						else
							printf("[]EXCEPTION sector not digit\n\n");
						// printf("NEIB : %s|%p   %d\n", vertex[i], vertex[i], it);
						map_add_vertex(&v, v_next);
					}
				
					it = iterate(3);
					i++;
				}

				// v_next = v;
				// while (v_next)
				// {
				// 	printf("%d | %d | %d\n", v_next->x,v_next->y,v_next->neighbor);
				// 	v_next = v_next->next;
				// }
				if (it != 0)
					printf("[%d]EXCEPTION - VERTEX SIZE != 3 \n\n",it);
				// printf("size %d\n\n", vertex_size);
				int j = -1;
				while (++j < i)
				{
					// printf(">>> %d|%p\n", j,vertex[j]);
					ft_memdel((void **)&(vertex[j]));
					
				}
				ft_memdel((void **)&(vertex));
				
			// 	printf(" \n");
				loop_str_to_value(&line, ";\0", sectors != NULL);
				ft_memdel((void **)&sectors);

				map_sector_new->vertex = v;
				map_sector_new->vertex_size = vertex_size;
				// map_del_vertex(&v);
			}
//--------------------------------------------------//
			char *level = cut_str_value(line, "level:\0", ";\0");
			char **lvl_info = ft_splinter(level, ",{}");
			int  k = 0;
			int it = 0;
			while (lvl_info && lvl_info[k] && k < 2){
				if (it == 0)
					map_sector_new->next_level = lvl_info[k];
				if (it == 1){
					if (lvl_info[k] && str_isdigit(lvl_info[k]))
					{
						map_sector_new->next_level = lvl_info[k];
					}
					else{
						printf("[]EXCEPTION next level sector not digit\n\n");
					}
				}
				// printf(" LEVEL %s\n", lvl_info[k]);
				ft_memdel((void **)&(lvl_info[k]));
				it = iterate(2);
				k++;
			}
			ft_memdel((void **)&(lvl_info));
			loop_str_to_value(&line, ";\0", level != NULL);
			ft_memdel((void **)&level);
			
			map_add_sector(&map_sector, map_sector_new);
			if (sector_size == 0)
				map = (t_map *)malloc(sizeof(t_map) * 1);
			map->sector = map_sector;
			map->sector_size = sector_size;
			sector_size++;

	}
}

int		main(int argc, char **argv)
{
	
	if (argc != 2)
		ft_putstr("\t usage : <./exe> <filename>");	
	char *filename = argv[1];
	// printf("%s\n", cut_str_value("test:cut;", "test:", ";"));
	t_map *map = (t_map *)for_each_gnl(filename, (void *)&line_parser);
	while(1);

	return (0);
}
